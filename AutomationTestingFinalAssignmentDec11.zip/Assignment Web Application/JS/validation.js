const carArray = [];

function validationForm() {
  const name = document.forms['carForm']['Name'];
  const email = document.forms['carForm']['Email'];
  const phone = document.forms['carForm']['Phone'];
  const city = document.forms['carForm']['City'];
  const address = document.forms['carForm']['Address'];
  const model = document.forms['carForm']['Model'];
  const modelMaker = document.forms['carForm']['ModelMaker'];
  const year = document.forms['carForm']['Year'];

  var nameError = document.getElementById('nameError');
  var emailError = document.getElementById('emailError');
  var phoneError = document.getElementById('phoneError');
  var cityError = document.getElementById('cityError');
  var addressError = document.getElementById('addressError');
  var modelError = document.getElementById('modelError');
  var modelMakerError = document.getElementById('modelMakerError');
  var yearError = document.getElementById('yearError');

  nameError.hidden = true;
  emailError.hidden = true;
  phoneError.hidden = true;
  cityError.hidden = true;
  addressError.hidden = true;
  modelError.hidden = true;
  modelMakerError.hidden = true;
  yearError.hidden = true;

  const emailPattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
  const phonePattern1 = /^([0-9]{3})-([0-9]{3})-([0-9]{4})$/;
  const phonePattern2 = /^\(([0-9]{3})\)([0-9]{3})-([0-9]{4})$/;

  if (name.value == '' || name.value.length <= 0) {
    nameError.hidden = false;
    nameError.innerText = "Name can't be empty";
    name.focus();
    return false;
  }
  if (email.value == '') {
    emailError.hidden = false;
    emailError.innerText = "Email can't be empty";
    email.focus();
    return false;
  }
  if (!email.value.match(emailPattern)) {
    emailError.hidden = false;
    emailError.innerText = 'Email id is not valid!';
    email.focus();
    return false;
  }

  if (phone.value == '') {
    phoneError.hidden = false;
    phoneError.innerText = "Phone can't be empty";
    phone.focus();
    return false;
  }

  if (!phone.value.match(phonePattern1) && !phone.value.match(phonePattern2)) {
    console.log(phone.value);
    phoneError.hidden = false;
    phoneError.innerText = 'Phone format is not valid';
    phone.focus();
    return false;
  }

  if (city.value == '') {
    cityError.hidden = false;
    cityError.innerText = "City can't be empty";
    city.focus();
    return false;
  }

  if (address.value == '') {
    addressError.hidden = false;
    addressError.innerText = "Address can't be empty";
    address.focus();
    return false;
  }

  if (modelMaker.value == '') {
    modelMakerError.hidden = false;
    modelMakerError.innerText = "Model Maker can't be empty";
    model.focus();
    return false;
  }

  if (model.value == '') {
    modelError.hidden = false;
    modelError.innerText = "Model No can't be empty";
    model.focus();
    return false;
  }

  if (year.value == '') {
    yearError.hidden = false;
    yearError.innerText = "Year  can't be empty";
    year.focus();
    return false;
  }
  if (year.value.length != 4) {
    yearError.hidden = false;
    yearError.innerText = 'Year is not valid';
    year.focus();
    return false;
  }

  const newCar = {
    SellerName: name.value,
    emailId: email.value,
    city: city.value,
    address: address.value,
    phone: phone.value,
    maker: modelMaker.value,
    model: model.value,
    year: year.value,
  };

  let storedCars = [];
  //   storedCars = JSON.parse(localStorage.getItem('Cars'));
  storedCars = JSON.parse(sessionStorage.getItem('Cars'));
  if (storedCars == null) {
    // localStorage.setItem('Cars', JSON.stringify([newCar]));
    sessionStorage.setItem('Cars', JSON.stringify([newCar]));
  } else {
    storedCars.push(newCar);

    // localStorage.setItem('Cars', JSON.stringify(storedCars));
    sessionStorage.setItem('Cars', JSON.stringify(storedCars));
  }
  sessionStorage.setItem('currentItem', JSON.stringify(newCar));

  return true;
}
