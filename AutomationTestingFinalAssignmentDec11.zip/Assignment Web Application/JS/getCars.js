var cars = document.getElementById('cars');
console.log(cars);
// const allCars = JSON.parse(localStorage.getItem('Cars'));
const allCars = JSON.parse(sessionStorage.getItem('Cars'));
console.log('All Cars', allCars, allCars.length);

let carName = '';
// https://www.jdpower.com/cars/2016/ford/mustang
allCars.filter((car) => {
  let carLink = '';
  carLink =
    'https://www.jdpower.com/cars/' +
    car.year +
    '/' +
    car.maker +
    '/' +
    car.model;
  carName +=
    '<a class="form-control" href=' +
    carLink +
    ' > ' +
    car.maker +
    '-' +
    car.model +
    '-' +
    car.year +
    '</a> <hr>';
  console.log('im ere', carName);
  cars.innerHTML = carName;
});
