let sellerName = document.getElementById('name');
let email = document.getElementById('email');
let phone = document.getElementById('phone');
let address = document.getElementById('address');
let city = document.getElementById('city');
let maker = document.getElementById('maker');
let model = document.getElementById('model');
let year = document.getElementById('year');

const currentCar = JSON.parse(sessionStorage.getItem('currentItem'));
console.log(currentCar, ' ', sellerName.innerHTML);
sellerName.innerHTML = '<strong>Seller Name: </strong>' + currentCar.SellerName;
email.innerHTML = '<strong>Email: </strong>' + currentCar.emailId;
phone.innerHTML = '<strong>Phone: </strong>' + currentCar.phone;
address.innerHTML = '<strong>Address: </strong>' + currentCar.address;
city.innerHTML = '<strong>City: </strong>' + currentCar.city;
maker.innerHTML = '<strong>Maker: </strong>' + currentCar.maker;
model.innerHTML = '<strong>Model: </strong>' + currentCar.model;
year.innerHTML = '<strong>Year: </strong>' + currentCar.year;

var carDiv = document.getElementById('carDiv');
// const allCars = JSON.parse(localStorage.getItem('Cars'));
let carAddressLink = '';
// https://www.jdpower.com/cars/2016/ford/mustang

let carLink = '';
carLink =
  'https://www.jdpower.com/cars/' +
  currentCar.year +
  '/' +
  currentCar.maker +
  '/' +
  currentCar.model;
carAddressLink +=
  '<a class="form-control" href=' +
  carLink +
  ' > ' +
  currentCar.maker +
  '-' +
  currentCar.model +
  '-' +
  currentCar.year +
  '</a> <hr>';
console.log(carAddressLink);
carDiv.innerHTML = carAddressLink;

function onClickHome() {
  sessionStorage.removeItem('currentItem');
}
